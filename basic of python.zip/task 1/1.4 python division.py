a = int(input())
b = int(input())
    
print("{0}\n{1}".format(a//b, a/b))