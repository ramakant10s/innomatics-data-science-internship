from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
import random
import string
import os

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///urls2.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

@app.before_first_request
def create_tables():
    db.create_all()

class urls2(db.Model):
    id = db.Column("id_", db.Integer, primary_key=True)
    long = db.Column("long", db.String())
    short = db.Column("short", db.String(12))

    def __init__(self, long, short):
        self.long = long
        self.short = short

def shorten_url():
    letters = string.ascii_lowercase + string.ascii_uppercase
    while True:
        rand_letters =  ''.join(random.SystemRandom().choice(
        string.ascii_letters + \
        string.digits) for _ in range(10))
        shorturl = urls2.query.filter_by(short=rand_letters).first()
        if not shorturl:
            return rand_letters


@app.route('/', methods=['POST', 'GET'])
def home():
    if request.method == "POST":
        url_input = request.form.get('url')
        valid_url = urls2.query.filter_by(long=url_input).first()

        if valid_url:
            endurl = "127.0.0.1:5000/"+valid_url.short
            return render_template('index.html', shortUrl = endurl)
        else:
            shorturl = shorten_url()
            print(shorturl)
            new_url = urls2(url_input, shorturl)
            db.session.add(new_url)
            db.session.commit()
            endurl = "127.0.0.1:5000/"+shorturl
            return render_template('index.html', shortUrl = endurl)
    else:
        return render_template('index.html')

@app.route('/<shorturl>')
def redirection(shorturl):
    long_url = urls2.query.filter_by(short=shorturl).first()
    if long_url:
        return redirect(long_url.long)
    else:
        return '<h1>Url doesnt exist</h1>'



@app.route('/history')
def display_all():
    return render_template('history.html', vals=urls2.query.all())

if __name__ == '__main__':
    app.run(debug=True)