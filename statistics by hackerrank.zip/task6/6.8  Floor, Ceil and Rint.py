import numpy as np
arr = list(map(float, input().split()))
out_put = (np.array(arr))
np.set_printoptions(sign =" ")
print(np.floor(out_put))
print(np.ceil(out_put))
print(np.rint(out_put))